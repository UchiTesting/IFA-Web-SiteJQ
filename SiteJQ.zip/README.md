## IFA  Langage Web cycle 2020 - Site jQuery

## 16/01/2020
Mise en place de l'espace GIT.

## Enoncé:
Créer un site monopage avec un bandeau en haut de page. Il contiendra un carousel avec 3 images défilant indéfiniment.
Sur la gauche un menu qui offre quelques liens qui déclenchent chacune une requête AJAX.
Dans le reste de la page, s'affiche le contenu du retour de requête formaté.